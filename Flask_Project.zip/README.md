
# Flask File Download Project

This is a simple Flask project that serves a file for download.

## How to run locally:
1. Install the dependencies:
   ```
   pip install -r requirements.txt
   ```
2. Run the application:
   ```
   python app.py
   ```
3. Access the file at `http://127.0.0.1:5000/download`.

## Deployment:
You can deploy this project to any Python-compatible hosting service like:
- Render
- PythonAnywhere
- Heroku
